(function($) {
    "use strict"

    new dlabSettings({
        sidebarPosition: "fixed"
    });


})(jQuery);